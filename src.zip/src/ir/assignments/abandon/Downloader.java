package ir.assignments.abandon;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

public class Downloader {

	public static void save_to_file(String name, String content) {
		String path = "/Users/nash/Documents/Workspaces/Java/CS121/Assignment 3/data/saved_data/";
		if ( name.contains(".txt") ) 
			path += "txt/" + name;
		else if ( name.contains(".html") )
			path += "html/" + name;

		try {
			File f = new File(name);
			
			PrintWriter pw = new PrintWriter(f);

			pw.print(content);

			pw.close();

		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
