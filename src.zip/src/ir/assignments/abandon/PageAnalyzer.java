package ir.assignments.abandon;


import ir.assignments.helper.Frequency;
import ir.assignments.helper.Utilities;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.TreeMap;



public class PageAnalyzer {

	// initialize and get the stop words path
	private static HashMap<String, Frequency> frequencies = new HashMap<String, Frequency>();;
	private static ArrayList<String> stopwords;

	// constructor
	// later
	/*
	public PageAnalyzer() {
		frequencies = new HashMap<String, Integer>();
		stopwords = new ArrayList<String>();
	}
	 */


	// store all stop words in a HashMap for better searching
	public static void load_stopwords(String path) {
		File file = new File(path);
		stopwords = Utilities.tokenizeFile(file);
	}

	public static void computeWordFrequencies(List<String> words) {
		// TODO Write body!

		// Using HashMap to get the frequency statistics
		for (String word : words) {
			if ( frequencies.containsKey(word) ) {
				frequencies.get(word).incrementFrequency();
			}
			else {
				frequencies.put(word, new Frequency(word, 1));
			}
		}

	}

	public static ArrayList<String> most_common(int k) {
		// sort the HashMap by values
		ArrayList<String> res = new ArrayList<String>();

		ArrayList<Frequency> sorted_frequencies = new ArrayList<Frequency>(frequencies.values());

		// sort by alphabets in reversed order
		Collections.sort(sorted_frequencies, new Comparator<Frequency>() {
			public int compare(Frequency f1, Frequency f2) {
				return -f1.getText().compareTo(f2.getText());
			}
		});

		// sort by frequencies
		Collections.sort(sorted_frequencies, new Comparator<Frequency>() {
			public int compare(Frequency f1, Frequency f2) {
				return (f1.getFrequency() > f2.getFrequency() ? 1 : -1);
			}
		});

		//get the top K elements
		for (int i = 0; i < k; i++) {
			Frequency to_add = sorted_frequencies.get(i);
			res.add(to_add.getText());
		}

		return res;
	}

	public static ArrayList<String> tokenizeText(String text) {
		ArrayList<String> res = new ArrayList<String>();

		StringTokenizer st = new StringTokenizer(text);
		while ( st.hasMoreTokens() ) {
			String next = st.nextToken();
			if (next.matches(".*[a-zA-Z0-9]")) {
				// remove punctuation
				next = next.replaceAll("[,.<>:;?1/\\[\\]()\"\'~_@#$%^&*+-=]", "");

				// stemming

				// remove stop words
				if ( !stopwords.contains(next) )
					res.add(next);
			}
		}

		return res;
	}

	public static HashMap<String, Frequency> getFrequencies() {
		return frequencies;
	}

	public static void store_cached_result(int i) {
		String path = "cache_" + i + ".txt";

		System.out.println("  get in");
		/*
		ArrayList<String> res = most_common(50);
		System.out.println("  res = " + res.toString());
		System.out.println("  get results");
		*/
		
		try {
			FileWriter fw = new FileWriter(path);
			PrintWriter pw = new PrintWriter(fw);
			
			
			pw.println("Cached results of frequencies");
			
			for (Frequency f : frequencies.values()) {
				System.out.println(f.toString());
				pw.println(f.toString());
			}
			
			pw.close();
			fw.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}
}
