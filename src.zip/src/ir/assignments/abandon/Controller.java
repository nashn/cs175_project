package ir.assignments.abandon;

import edu.uci.ics.crawler4j.crawler.CrawlConfig;
import edu.uci.ics.crawler4j.crawler.CrawlController;
import edu.uci.ics.crawler4j.fetcher.PageFetcher;
import edu.uci.ics.crawler4j.robotstxt.RobotstxtConfig;
import edu.uci.ics.crawler4j.robotstxt.RobotstxtServer;


public class Controller {
	
	private static String userAgent = "UCI Inf131-CS121 crawler 77134417";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// set logger here later
		
		// configuration parameters
		String crawlStorageFolder = "";
		
		int numberOfCrawlers = 5;
		int delay = 300;
		
		
		String startUrl = "";
		
		
		// configuration settings
		CrawlConfig config = new CrawlConfig();
		
		config.setUserAgentString(userAgent);
		config.setCrawlStorageFolder(crawlStorageFolder);
		config.setPolitenessDelay(delay);
		config.setMaxDepthOfCrawling(2);
		config.setIncludeBinaryContentInCrawling(false);
		config.setResumableCrawling(true);

		PageFetcher pageFetcher = new PageFetcher(config);
		RobotstxtConfig robotstxtConfig = new RobotstxtConfig();
		RobotstxtServer robotstxtServer = new RobotstxtServer(robotstxtConfig, pageFetcher);
		
		
		// get the Page Analyzer ready
		String stopwords_path = "";
		PageAnalyzer.load_stopwords(stopwords_path);
		
		try {
			CrawlController controller = new CrawlController(config, pageFetcher, robotstxtServer);
			controller.addSeed(startUrl);
		
			// start timer
			long start = System.currentTimeMillis();
			controller.start(Crawler.class, numberOfCrawlers);
			// stop timer
			// compute elapsed time
			long elapsed_time = System.currentTimeMillis() - start;
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
