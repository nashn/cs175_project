package ir.assignments.helper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;


/*
 * @author: She Nie
 * @ID#: 77134417
 * 
 * Description: A collection of utility functions for getting word frequencies
 * */

/**
 * A collection of utility methods for text processing.
 */
public class Utilities {
	
	// updated 01-31-2015
	//	add loading stopwords here
	private static ArrayList<String> stopwords = new ArrayList<String>();
	public static void load_stopwords(String path) {
		try {
			FileReader fr = new FileReader(path);
			Scanner sc = new Scanner(fr);
			
			while ( sc.hasNextLine() ) {
				String nextline = sc.nextLine();
				if ( !nextline.equals("\n") )
					stopwords.add(nextline);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Reads the input text file and splits it into alphanumeric tokens.
	 * Returns an ArrayList of these tokens, ordered according to their
	 * occurrence in the original text file.
	 * 
	 * Non-alphanumeric characters delineate tokens, and are discarded.
	 *
	 * Words are also normalized to lower case. 
	 * 
	 * Example:
	 * 
	 * Given this input string
	 * "An input string, this is! (or is it?)"
	 * 
	 * The output list of strings should be
	 * ["an", "input", "string", "this", "is", "or", "is", "it"]
	 * 
	 * @param input The file to read in and tokenize.
	 * @return The list of tokens (words) from the input file, ordered by occurrence.
	 */
	public static ArrayList<String> tokenizeFile(File input) {
		// TODO Write body!
		ArrayList<String> res = new ArrayList<String>();

		
		// updated 01-31-2015
		//	doing tokenizing with stopwords
		load_stopwords("./stopwords.txt");
		
		try {
			FileReader fr = new FileReader(input);

			Scanner scanner = new Scanner(fr);

			String line = "";
			while ( scanner.hasNextLine() ) {
				line = scanner.nextLine();
				
				String[] tokens = line.split("[^1-9a-zA-Z]");
				for (String t : tokens) {
					t = t.trim();
					if ( !stopwords.contains(t) && !t.equals(null) && !t.equals("") )
						res.add(t.toLowerCase());
				}
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return res;
	}

	/**
	 * Takes a list of {@link Frequency}s and prints it to standard out. It also
	 * prints out the total number of items, and the total number of unique items.
	 * 
	 * Example one:
	 * 
	 * Given the input list of word frequencies
	 * ["sentence:2", "the:1", "this:1", "repeats:1",  "word:1"]
	 * 
	 * The following should be printed to standard out
	 * 
	 * Total item count: 6
	 * Unique item count: 5
	 * 
	 * sentence	2
	 * the		1
	 * this		1
	 * repeats	1
	 * word		1
	 * 
	 * 
	 * Example two:
	 * 
	 * Given the input list of 2-gram frequencies
	 * ["you think:2", "how you:1", "know how:1", "think you:1", "you know:1"]
	 * 
	 * The following should be printed to standard out
	 * 
	 * Total 2-gram count: 6
	 * Unique 2-gram count: 5
	 * 
	 * you think	2
	 * how you		1
	 * know how		1
	 * think you	1
	 * you know		1
	 * 
	 * @param frequencies A list of frequencies.
	 */
	public static void printFrequencies(List<Frequency> frequencies) {
		// TODO Write body!
		int total = 0;
		int unique = frequencies.size();
		String type = "item";

		// checking whether the frequencies list is for 2-gram.
		for (Frequency f : frequencies) {
			total += f.getFrequency();
			if ( f.getText().contains(" ") ) 
				type ="2-gram";
		}

		// checking whether the frequencies list is for palindrome
		int space = 0;
		for (Frequency f : frequencies) {
			
			for (int i = 0; i < f.getText().length(); i++)
				if ( f.getText().charAt(i) == ' ' ) 
					space++;
			if (space > 1)
				type ="palindrome";
		}

		System.out.println("Total " + type + " count: " + total);
		System.out.println("Unique " + type + " count: " + unique);

		// updated 01-31-2015:
		//	doing sorting in frequencies counters
		for (Frequency f : frequencies) {
			System.out.println( f.toString() );
		}
		
		/*
		// Doing sorting here:
		// Since the all the frequency lists for three different types of patter
		// is generic, and the sorting also follows the same way, so move the sorting part to here

		// sort by alphabets
		Collections.sort(frequencies, new Comparator<Frequency>() {
			public int compare(Frequency f1, Frequency f2) {
				return f1.getText().compareTo(f2.getText());
			}
		});

		// sort by frequencies
		Collections.sort(frequencies, new Comparator<Frequency>() {
			public int compare(Frequency f1, Frequency f2) {
				return (f1.getFrequency() > f2.getFrequency() ? -1 : 1);
			}
		});

		// no need to do formatting, just use the simplest way
		for (Frequency f : frequencies) {
			//System.out.println(f.getText() + "     " + f.getFrequency());
			System.out.println(String.format("%-10s%3d", f.getText(), f.getFrequency()));
		}
		*/
	}
}
