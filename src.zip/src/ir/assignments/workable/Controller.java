package ir.assignments.workable;


import edu.uci.ics.crawler4j.crawler.CrawlConfig;
import edu.uci.ics.crawler4j.crawler.CrawlController;
import edu.uci.ics.crawler4j.fetcher.PageFetcher;
import edu.uci.ics.crawler4j.robotstxt.RobotstxtConfig;
import edu.uci.ics.crawler4j.robotstxt.RobotstxtServer;

// problems to import logger, need to change to the other one
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;



public class Controller {

	private static String userAgent = "UCI Inf131-CS121 crawler 77134417";

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// set logger here later

		// configuration parameters
		String crawlStorageFolder = "data/crawl/root";

		int numberOfCrawlers = 5;

		// configuration settings
		CrawlConfig config = new CrawlConfig();

		config.setUserAgentString(userAgent);
		config.setCrawlStorageFolder(crawlStorageFolder);
		config.setPolitenessDelay(300);
		config.setMaxDepthOfCrawling(2);
		config.setIncludeBinaryContentInCrawling(false);
		config.setResumableCrawling(true);

		
		// initializing configurations
		PageFetcher pageFetcher = new PageFetcher(config);
		RobotstxtConfig robotstxtConfig = new RobotstxtConfig();
		RobotstxtServer robotstxtServer = new RobotstxtServer(robotstxtConfig, pageFetcher);


		// get the Page Analyzer ready
		
		try {
			CrawlController controller = new CrawlController(config, pageFetcher, robotstxtServer);
			controller.addSeed("http://www.ics.uci.edu/");

			// start timer
			long start = System.currentTimeMillis();
			controller.start(Crawler.class, numberOfCrawlers);
			// stop timer
			// compute elapsed time
			long elapsed_time = System.currentTimeMillis() - start;
			
			System.out.println("Total runtime = " + elapsed_time + "ms");


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

}
