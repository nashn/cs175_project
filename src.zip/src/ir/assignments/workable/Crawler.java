package ir.assignments.workable;

import ir.assignments.helper.Utilities;

import java.util.Collection;
import java.util.List;

import edu.uci.ics.crawler4j.crawler.Page;
import edu.uci.ics.crawler4j.crawler.WebCrawler;
import edu.uci.ics.crawler4j.parser.HtmlParseData;
import edu.uci.ics.crawler4j.url.WebURL;

import java.util.Set;
import java.util.regex.Pattern;

import org.apache.http.Header;


//problems to import logger, need to change to the other one
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.apache.log4j.*;

public class Crawler extends WebCrawler{
	/**
	 * This method is for testing purposes only. It does not need to be used
	 * to answer any of the questions in the assignment. However, it must
	 * function as specified so that your crawler can be verified programatically.
	 * 
	 * This methods performs a crawl starting at the specified seed URL. Returns a
	 * collection containing all URLs visited during the crawl.
	 */
	public static Collection<String> crawl(String seedURL) {
		// TODO implement me

		return null;
	}


	private final static Pattern BINARY_FILES_EXTENSIONS =
			Pattern.compile(".*\\.(bmp|gif|jpe?g|png|tiff?|pdf|ico|xaml|pict|rif|pptx?|ps" +
					"|mid|mp2|mp3|mp4|wav|wma|au|aiff|flac|ogg|3gp|aac|amr|au|vox" +
					"|avi|mov|mpe?g|ra?m|m4v|smil|wm?v|swf|aaf|asf|flv|mkv" +
					"|zip|rar|gz|7z|aac|ace|alz|apk|arc|arj|dmg|jar|lzip|lha)" +
					"(\\?.*)?$"); // For url Query parts ( URL?q=... )

	// REGEX to filter all legal doamin & subdomains
	private final static Pattern DOMAIN_FILTERS = Pattern.compile("http://((.*\\.ics\\.uci\\.edu)|(ics\\.uci\\.edu))/.*");

	// Keep adding the crawling traps
	private final static String[] TRAPS = {"http://calendar.ics.uci.edu/calendar.php?type=month&calendar=1&category=&",
											"more later"}; 


	/**
	 * You should implement this function to specify whether the given url
	 * should be crawled or not (based on your crawling logic).
	 */
	public boolean shouldVisit(Page page, WebURL url) {
		String href = url.getURL().toLowerCase();

		// first check if the URL is a trap
		// if yes then skip it
		for (String trap : TRAPS) {
			if ( href.startsWith(trap) ) {
				System.out.println("==========TRAP==========");
				System.out.println("Encounter trap url: " + href + "\nSkip!");
				System.out.println("========================");
				return false;
			}
		}

		// original example
		//return !BINARY_FILES_EXTENSIONS.matcher(href).matches() && href.startsWith("http://www.ics.uci.edu/");
		
		// not enough, contains() has vagueness
		//return !BINARY_FILES_EXTENSIONS.matcher(href).matches() && href.contains("ics.uci.edu/");
		
		// using regex filter
		return !BINARY_FILES_EXTENSIONS.matcher(href).matches() && DOMAIN_FILTERS.matcher(href).matches();
	}
	
	//private Logger logger = LogManager.getLogger( Crawler.class.getName() );

	private PageAnalyzer analyzer = new PageAnalyzer();
	
	/**
	 * This function is called when a page is fetched and ready to be processed
	 * by your program.
	 */
	@Override
	public void visit(Page page) {
		int docid = page.getWebURL().getDocid();
		String url = page.getWebURL().getURL();
		String domain = page.getWebURL().getDomain();
		String path = page.getWebURL().getPath();
		String subDomain = page.getWebURL().getSubDomain();
		String parentUrl = page.getWebURL().getParentUrl();
		String anchor = page.getWebURL().getAnchor();

		analyzer.count_url(url);
		analyzer.save_subdomain(subDomain);
		
		System.out.println("Docid: " + docid);
		System.out.println("URL: " + url);
		System.out.println("Domain: " + domain);
		System.out.println("Sub-domain: " + subDomain);
		System.out.println("Path: " + path);
		System.out.println("Parent page: " + parentUrl);
		System.out.println("Anchor text: " + anchor);

		if (page.getParseData() instanceof HtmlParseData) {
			HtmlParseData htmlParseData = (HtmlParseData) page.getParseData();
			String text = htmlParseData.getText();
			String html = htmlParseData.getHtml();
			List<WebURL> links = htmlParseData.getOutgoingUrls();
			

			analyzer.compare_page(text.length());
			analyzer.save_to_temp(text);
			analyzer.analyze_frequencies();
			
			analyzer.save_intermedia();
			
			System.out.println("Text length: " + text.length());
			System.out.println("Html length: " + html.length());
			System.out.println("Number of outgoing links: " + links.size());
		}

		Header[] responseHeaders = page.getFetchResponseHeaders();
		if (responseHeaders != null) {
			System.out.println("Response headers:");
			for (Header header : responseHeaders) {
				System.out.println("\t" + header.getName() + ": " + header.getValue());
			}
		}

		System.out.println("=============");
	}

}
