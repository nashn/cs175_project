package ir.assignments.three;

import ir.assignments.helper.Frequency;
import ir.assignments.helper.Utilities;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;

public class PageAnalyzer {

	private static int longest_page = 0;
	private static int url_counter = 0;
	
	private static HashMap<String, Frequency> counter = new HashMap<String, Frequency>();
	private static HashSet<String> unique_urls = new HashSet<String>();
	private static HashSet<String> subdomains = new HashSet<String>();
	
	/*
	public static PageAnalyzer() {
		longest_page = 0;
		url_counter = 0;
		counter = new HashMap<String, Frequency>();
		unique_urls = new HashSet<String>();
		subdomains = new HashSet<String>();
	}
	*/

	public static int get_longest_page() {
		return longest_page;
	}

	public static void compare_page(int page_length) {
		if ( page_length > longest_page )
			longest_page = page_length;
	}

	public static void save_to_temp(String text) {
		try {
			File f = new File("./temp.txt");

			PrintWriter pw = new PrintWriter(f);

			pw.print(text);

			pw.close();

		} catch(Exception e) {
			e.printStackTrace();
		}
	}


	public static void analyze_frequencies() {

		File input = new File("./temp.txt");
		ArrayList<String> words = Utilities.tokenizeFile(input);

		// Using HashMap to get the frequency statistics
		for (String word : words) {
			if ( counter.containsKey(word) )
				counter.get(word).incrementFrequency();
			else
				counter.put(word, new Frequency(word, 1));
		}

	}

	public static ArrayList<Frequency> get_word_frequencies() {
		ArrayList<Frequency> res = new ArrayList<Frequency>();
		
		res.addAll(counter.values());

		// sort here later
		// move to the printFrequencies() in utilities
		// updated 01-31-2015
		//	moving sorting back to this part
		Collections.sort(res, new Comparator<Frequency>() {
			public int compare(Frequency f1, Frequency f2) {
				return f1.getText().compareTo(f2.getText());
			}
		});

		// sort by frequencies
		Collections.sort(res, new Comparator<Frequency>() {
			public int compare(Frequency f1, Frequency f2) {
				return f2.getFrequency() - f1.getFrequency();
			}
		});
		
		return res;
	}

	public static void count_url(String url) {
		if ( !unique_urls.contains(url) && url.contains("ics.uci.edu") )
			unique_urls.add(url);
		url_counter++;
	}
	
	public static int get_total_visited_url_count() {
		return url_counter;
	}

	public static int get_total_unique_url_count() {
		return unique_urls.size();
	}
	
	public static void save_subdomain(String subDomain) {
		if ( !subdomains.contains(subDomain) && subDomain.matches(".*\\.(ics)") )
			subdomains.add(subDomain);
	}

	public static void save_intermedia() {
		ArrayList<Frequency> sorted_frequency = get_word_frequencies();
		
		try {
			FileWriter fw0 = new FileWriter("unique_urls.txt");
			PrintWriter pw0 = new PrintWriter(fw0);
			
			FileWriter fw1 = new FileWriter("subs.txt");
			FileWriter fw2 = new FileWriter("commons.txt");  
			
			PrintWriter pw1 = new PrintWriter(fw1);
			PrintWriter pw2 = new PrintWriter(fw2);
			
			// save all unique_urls
			pw0.println("Current longest page size = " + longest_page);
			pw0.println("Current unique size       = " + unique_urls.size());
			pw0.println("Current total size        = " + url_counter);
			for (String s : unique_urls) {
				// sorting later
				pw0.println(s);
			}
			pw0.close();
			fw0.close();
			
			// save subdomains
			for (String s : subdomains) {
				// sorting later
				pw1.println(s);
			}
			pw1.close();
			
			// save top 500 frequencies
			int size = (sorted_frequency.size() > 500) ? 500 : sorted_frequency.size();
			for (int i = 0; i < size; i++) {
				pw2.println( sorted_frequency.get(i).toString() );;
			}
			pw2.close();
			
			
			fw2.close();
			fw1.close();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}



}
