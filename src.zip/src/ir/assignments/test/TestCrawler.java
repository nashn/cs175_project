package ir.assignments.test;

import ir.assignments.abandon.Downloader;
import ir.assignments.abandon.PageAnalyzer;
import ir.assignments.helper.Frequency;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;

import edu.uci.ics.crawler4j.crawler.Page;
import edu.uci.ics.crawler4j.crawler.WebCrawler;
import edu.uci.ics.crawler4j.parser.HtmlParseData;
import edu.uci.ics.crawler4j.url.WebURL;

public class TestCrawler extends WebCrawler{
	/**
	 * This method is for testing purposes only. It does not need to be used
	 * to answer any of the questions in the assignment. However, it must
	 * function as specified so that your crawler can be verified programatically.
	 * 
	 * This methods performs a crawl starting at the specified seed URL. Returns a
	 * collection containing all URLs visited during the crawl.
	 */	
	public static Collection<String> crawl(String seedURL) {
		// TODO implement me
		ArrayList<String> res = new ArrayList<String>();
		
		if ( !res.contains(seedURL) )
			res.add(seedURL);
		
		return res;
	}
	
	private static int counter = 0;

	private final static Pattern BINARY_FILES_EXTENSIONS =
	        Pattern.compile(".*\\.(bmp|gif|jpe?g|png|tiff?|pdf|ico|xaml|pict|rif|pptx?|ps" +
	        "|mid|mp2|mp3|mp4|wav|wma|au|aiff|flac|ogg|3gp|aac|amr|au|vox" +
	        "|avi|mov|mpe?g|ra?m|m4v|smil|wm?v|swf|aaf|asf|flv|mkv" +
	        "|zip|rar|gz|7z|aac|ace|alz|apk|arc|arj|dmg|jar|lzip|lha)" +
	        "(\\?.*)?$"); // For url Query parts ( URL?q=... )

	  /**
	   * You should implement this function to specify whether the given url
	   * should be crawled or not (based on your crawling logic).
	   */
	  public boolean shouldVisit(Page page, WebURL url) {
	    String href = url.getURL().toLowerCase();

	    return !BINARY_FILES_EXTENSIONS.matcher(href).matches() && href.startsWith("http://www.ics.uci.edu/");
	  }

	/**
	 * This function is called when a page is fetched and ready 
	 * to be processed by your program.
	 */
	@Override
	public void visit(Page page) {
		int docid = page.getWebURL().getDocid();
	    String url = page.getWebURL().getURL();
	    String domain = page.getWebURL().getDomain();
	    String path = page.getWebURL().getPath();
	    String subDomain = page.getWebURL().getSubDomain();
	    String parentUrl = page.getWebURL().getParentUrl();
	    String anchor = page.getWebURL().getAnchor();
	    
		
		// record URLs & subdomains
		
		System.out.println("URL: " + url);

		if (page.getParseData() instanceof HtmlParseData) {
			HtmlParseData htmlParseData = (HtmlParseData) page.getParseData();
			String text = htmlParseData.getText();
			String html = htmlParseData.getHtml();
			List<WebURL> links = htmlParseData.getOutgoingUrls();
			
			counter++;
			
			// compute frequencies here
			// remove stopwords
			//System.out.println(text);
			
			ArrayList<String> words = PageAnalyzer.tokenizeText(text);
			PageAnalyzer.computeWordFrequencies(words);
			
			ArrayList<Frequency> fre = new ArrayList<Frequency>(PageAnalyzer.getFrequencies().values());
			
			String name = counter + ".txt";
			Downloader.save_to_file(name, text);
			name = counter + ".html";
			Downloader.save_to_file(name, html);
			/*
			System.out.println("\n\n\n===============================================================");
			for (Frequency f : fre) {
				System.out.println(f.toString());
			}
			System.out.println("\n\n\n///////////////////////////////////////////////////////////////");
			
			
			
			/*
			System.out.println("Text length: " + text.length());
			System.out.println("Html length: " + html.length());
			System.out.println("Number of outgoing links: " + links.size());
			*/
			//System.out.println("  counter = " + (++counter));
			
			if ( counter % 100 == 0 ) {
				System.out.println("Write the partial results");
				int temp = counter / 100;
				PageAnalyzer.store_cached_result(temp);
			}
		}
	}
}

