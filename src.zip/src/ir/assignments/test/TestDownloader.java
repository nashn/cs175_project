package ir.assignments.test;

import org.apache.http.HttpStatus;

import edu.uci.ics.crawler4j.crawler.CrawlConfig;
import edu.uci.ics.crawler4j.crawler.Page;
import edu.uci.ics.crawler4j.fetcher.PageFetchResult;
import edu.uci.ics.crawler4j.fetcher.PageFetcher;
import edu.uci.ics.crawler4j.parser.HtmlParseData;
import edu.uci.ics.crawler4j.parser.ParseData;
import edu.uci.ics.crawler4j.parser.Parser;
import edu.uci.ics.crawler4j.url.WebURL;

import java.io.IOException;

/**
 * This class is a demonstration of how crawler4j can be used to download a
 * single page and extract its title and text.
 */
public class TestDownloader {

	private Parser parser;
	private PageFetcher pageFetcher;
	//private Logger logger = LoggerFactory.getLogger(Downloader.class);

	public TestDownloader() {
		CrawlConfig config = new CrawlConfig();
		parser = new Parser(config);
		pageFetcher = new PageFetcher(config);
	}

	public static void main(String[] args) {
		TestDownloader downloader = new TestDownloader();
		downloader.processUrl("http://en.wikipedia.org/wiki/Main_Page/");
		downloader.processUrl("http://www.yahoo.com/");
	}

	public void processUrl(String url) {
		System.out.println("Processing: " + url);
		Page page = download(url);
		if (page != null) {
			ParseData parseData = page.getParseData();
			if (parseData != null) {
				if (parseData instanceof HtmlParseData) {
					HtmlParseData htmlParseData = (HtmlParseData) parseData;
					System.out.println("Title: " + htmlParseData.getTitle());
					System.out.println("Text length: " + htmlParseData.getText().length());
					System.out.println("Html length: " + htmlParseData.getHtml().length());
				}
			} else {
				System.out.println("Couldn't parse the content of the page.");
			}
		} else {
			System.out.println("Couldn't fetch the content of the page.");
		}
		System.out.println("==============");
	}

	private Page download(String url) {
		WebURL curURL = new WebURL();
		curURL.setURL(url);
		PageFetchResult fetchResult = null;
		try {
			fetchResult = pageFetcher.fetchHeader(curURL);
			if (fetchResult.getStatusCode() == HttpStatus.SC_OK) {
				Page page = new Page(curURL);
				fetchResult.fetchContent(page);
				parser.parse(page, curURL.getURL());
				return page;
			}
		} catch (Exception e) {
			System.out.println("Error occurred while fetching url: " + curURL.getURL());
		} finally {
			if (fetchResult != null)
			{
				fetchResult.discardContentIfNotConsumed();
			}
		}
		return null;
	}
}