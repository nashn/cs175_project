package ir.assignments.test;

import ir.assignments.abandon.PageAnalyzer;
import edu.uci.ics.crawler4j.crawler.CrawlConfig;
import edu.uci.ics.crawler4j.crawler.CrawlController;
import edu.uci.ics.crawler4j.fetcher.PageFetcher;
import edu.uci.ics.crawler4j.robotstxt.RobotstxtConfig;
import edu.uci.ics.crawler4j.robotstxt.RobotstxtServer;

public class TestController {
	public static void main(String[] args) throws Exception {
		String crawlStorageFolder = "/Users/nash/Documents/Workspaces/Java/CS121/Assignment 3/data/crawl/root";
		int numberOfCrawlers = 7;

		CrawlConfig config = new CrawlConfig();
		config.setCrawlStorageFolder(crawlStorageFolder);

		config.setPolitenessDelay(300);
		config.setIncludeBinaryContentInCrawling(false);
		config.setResumableCrawling(true);
		
	    //config.setMaxPagesToFetch(1000);
		/*
		 * Instantiate the controller for this crawl.
		 */
		PageFetcher pageFetcher = new PageFetcher(config);
		RobotstxtConfig robotstxtConfig = new RobotstxtConfig();
		RobotstxtServer robotstxtServer = new RobotstxtServer(robotstxtConfig, pageFetcher);
		CrawlController controller = new CrawlController(config, pageFetcher, robotstxtServer);

		/*
		 * For each crawl, you need to add some seed urls. These are the first
		 * URLs that are fetched and then the crawler starts following links
		 * which are found in these pages
		 */
		controller.addSeed("http://www.ics.uci.edu/");


		// get the Page Analyzer ready
		String stopwords_path = "/Users/nash/Documents/Workspaces/Java/CS121/Assignment 3/stopwords.txt";
		PageAnalyzer.load_stopwords(stopwords_path);

		/*
		 * Start the crawl. This is a blocking operation, meaning that your code
		 * will reach the line after this only when crawling is finished.
		 */
		long start = System.currentTimeMillis();

		controller.start(TestCrawler.class, numberOfCrawlers);   

		long total = System.currentTimeMillis() - start;
		
		System.out.println("\n============\nelapsed time = " + total + "ms\n============\n");
		PageAnalyzer.most_common(500);
	}
}